import json
import hashlib
import os
from datetime import datetime

# 数据库文件
DB_FILE = "crm_database.json"

class CRMSystem:
    def __init__(self):
        self.load_database()
    
    def load_database(self):
        """加载数据库文件"""
        if os.path.exists(DB_FILE):
            with open(DB_FILE, 'r', encoding='utf-8') as f:
                self.db = json.load(f)
        else:
            # 初始化数据库结构
            self.db = {
                "companies": {},
                "customers": {},
                "chats": {}
            }
    
    def save_database(self):
        """保存数据库文件"""
        # 使用文件锁确保线程安全
        import threading
        with threading.Lock():
            with open(DB_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.db, f, ensure_ascii=False, indent=2)
    
    def hash_password(self, password):
        """密码哈希处理"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def register_company(self, username, password):
        """注册企业账号"""
        import threading
        with threading.Lock():
            if username in self.db["companies"]:
                return False, "账号已存在"
            
            self.db["companies"][username] = {
                "password": self.hash_password(password),
                "create_time": datetime.now().isoformat()
            }
            self.save_database()
            return True, "注册成功"
    
    def register_customer(self, username, password, name, age, gender):
        """注册客户账号"""
        import threading
        with threading.Lock():
            if username in self.db["customers"]:
                return False, "账号已存在"
            
            self.db["customers"][username] = {
                "password": self.hash_password(password),
                "name": name,
                "age": age,
                "gender": gender,
                "status": "潜在客户",
                "create_time": datetime.now().isoformat()
            }
            self.save_database()
            return True, "注册成功"
    
    def login(self, username, password, user_type):
        """用户登录"""
        if user_type == "company":
            if username not in self.db["companies"]:
                return False, "非法账号"
            
            if self.db["companies"][username]["password"] != self.hash_password(password):
                return False, "密码错误"
            
            return True, "登录成功"
        
        elif user_type == "customer":
            if username not in self.db["customers"]:
                return False, "非法账号"
            
            if self.db["customers"][username]["password"] != self.hash_password(password):
                return False, "密码错误"
            
            return True, "登录成功"
        
        else:
            return False, "无效用户类型"
    
    def get_customer_list(self):
        """获取客户列表"""
        return self.db["customers"]
    
    def update_customer_status(self, username, status):
        """更新客户状态"""
        if username not in self.db["customers"]:
            return False, "客户不存在"
        
        self.db["customers"][username]["status"] = status
        self.save_database()
        return True, "状态更新成功"
    
    def send_message(self, from_user, to_user, content, message_type):
        """发送消息"""
        # 确保聊天记录存在
        chat_key = f"{from_user}_{to_user}"
        reverse_key = f"{to_user}_{from_user}"
        
        if chat_key not in self.db["chats"] and reverse_key not in self.db["chats"]:
            self.db["chats"][chat_key] = []
        
        chat_key = chat_key if chat_key in self.db["chats"] else reverse_key
        
        message = {
            "from": from_user,
            "to": to_user,
            "content": content,
            "time": datetime.now().isoformat(),
            "type": message_type
        }
        
        self.db["chats"][chat_key].append(message)
        self.save_database()
        return True, "消息发送成功"
    
    def get_chat_history(self, user1, user2):
        """获取聊天历史"""
        chat_key = f"{user1}_{user2}"
        reverse_key = f"{user2}_{user1}"
        
        if chat_key in self.db["chats"]:
            return self.db["chats"][chat_key]
        elif reverse_key in self.db["chats"]:
            return self.db["chats"][reverse_key]
        else:
            return []

def company_menu(crm, username):
    """企业管理菜单"""
    while True:
        print("\n=== 企业管理系统 ===")
        print("1. 查看客户列表")
        print("2. 更新客户状态")
        print("3. 发送消息给客户")
        print("4. 查看聊天记录")
        print("5. 退出")
        
        choice = input("请选择操作: ")
        
        if choice == "1":
            customers = crm.get_customer_list()
            print("\n=== 客户列表 ===")
            for idx, (user, info) in enumerate(customers.items(), 1):
                print(f"{idx}. 账号: {user}")
                print(f"   姓名: {info['name']}")
                print(f"   年龄: {info['age']}")
                print(f"   性别: {info['gender']}")
                print(f"   状态: {info['status']}")
                print()
        
        elif choice == "2":
            customer_user = input("请输入客户账号: ")
            status = input("请输入新状态(如: 潜在客户, 意向客户, 成交客户, 流失客户): ")
            success, msg = crm.update_customer_status(customer_user, status)
            print(msg)
        
        elif choice == "3":
            customer_user = input("请输入客户账号: ")
            content = input("请输入消息内容: ")
            success, msg = crm.send_message(username, customer_user, content, "company")
            print(msg)
        
        elif choice == "4":
            customer_user = input("请输入客户账号: ")
            history = crm.get_chat_history(username, customer_user)
            print("\n=== 聊天记录 ===")
            for msg in history:
                sender = "企业" if msg["type"] == "company" else "客户"
                time = datetime.fromisoformat(msg["time"]).strftime("%Y-%m-%d %H:%M:%S")
                print(f"[{time}] {sender}: {msg['content']}")
        
        elif choice == "5":
            break
        
        else:
            print("无效选择, 请重新输入")

def customer_menu(crm, username):
    """客户菜单"""
    while True:
        print("\n=== 客户系统 ===")
        print("1. 查看个人信息")
        print("2. 发送消息给企业")
        print("3. 查看聊天记录")
        print("4. 退出")
        
        choice = input("请选择操作: ")
        
        if choice == "1":
            info = crm.db["customers"][username]
            print("\n=== 个人信息 ===")
            print(f"姓名: {info['name']}")
            print(f"年龄: {info['age']}")
            print(f"性别: {info['gender']}")
            print(f"状态: {info['status']}")
        
        elif choice == "2":
            company_user = input("请输入企业账号: ")
            content = input("请输入消息内容: ")
            success, msg = crm.send_message(username, company_user, content, "customer")
            print(msg)
        
        elif choice == "3":
            company_user = input("请输入企业账号: ")
            history = crm.get_chat_history(username, company_user)
            print("\n=== 聊天记录 ===")
            for msg in history:
                sender = "企业" if msg["type"] == "company" else "客户"
                time = datetime.fromisoformat(msg["time"]).strftime("%Y-%m-%d %H:%M:%S")
                print(f"[{time}] {sender}: {msg['content']}")
        
        elif choice == "4":
            break
        
        else:
            print("无效选择, 请重新输入")

def main():
    crm = CRMSystem()
    
    while True:
        print("\n=== 客户关系管理系统 ===")
        print("1. 企业注册")
        print("2. 客户注册")
        print("3. 登录")
        print("4. 退出")
        
        choice = input("请选择操作: ")
        
        if choice == "1":
            username = input("请输入企业账号: ")
            password = input("请输入密码: ")
            success, msg = crm.register_company(username, password)
            print(msg)
        
        elif choice == "2":
            username = input("请输入客户账号: ")
            password = input("请输入密码: ")
            name = input("请输入姓名: ")
            age = input("请输入年龄: ")
            gender = input("请输入性别: ")
            success, msg = crm.register_customer(username, password, name, age, gender)
            print(msg)
        
        elif choice == "3":
            username = input("请输入账号: ")
            password = input("请输入密码: ")
            user_type = input("请输入用户类型(company/customer): ")
            
            success, msg = crm.login(username, password, user_type)
            print(msg)
            
            if success:
                if user_type == "company":
                    company_menu(crm, username)
                elif user_type == "customer":
                    customer_menu(crm, username)
        
        elif choice == "4":
            break
        
        else:
            print("无效选择, 请重新输入")

if __name__ == "__main__":
    main()