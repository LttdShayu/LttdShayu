#!/usr/bin/env python3
"""
CRM系统性能测试套件
可选择单独测试或完整测试，包含AI分析接口
"""

import time
import random
import string
import threading
import requests
import psutil
from typing import List, Dict, Callable
from datetime import datetime

# AI分析配置
AI_API_URL = "https://ai.liaobots.work/v1beta/models/gemini-3-pro-preview:generateContent"
AI_API_KEY = ""  # 需要用户填入API密钥

class CRMTestResult:
    """测试结果数据结构"""
    def __init__(self, test_name: str):
        self.test_name = test_name
        self.start_time = datetime.now()
        self.end_time = None
        self.duration = 0
        self.success_count = 0
        self.fail_count = 0
        self.response_times: List[float] = []
        self.error_messages: List[str] = []
        
    def add_result(self, success: bool, response_time: float = 0, error_msg: str = ""):
        """添加单个测试结果"""
        if success:
            self.success_count += 1
            self.response_times.append(response_time)
        else:
            self.fail_count += 1
            self.error_messages.append(error_msg)
    
    def finalize(self):
        """完成测试，计算统计数据"""
        self.end_time = datetime.now()
        self.duration = (self.end_time - self.start_time).total_seconds()
        
    def get_summary(self) -> Dict:
        """获取测试结果摘要"""
        total = self.success_count + self.fail_count
        success_rate = (self.success_count / total * 100) if total > 0 else 0
        avg_response = sum(self.response_times) / len(self.response_times) if self.response_times else 0
        
        return {
            "test_name": self.test_name,
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat(),
            "duration": round(self.duration, 2),
            "total_requests": total,
            "success_count": self.success_count,
            "fail_count": self.fail_count,
            "success_rate": round(success_rate, 2),
            "avg_response_time": round(avg_response, 3),
            "min_response_time": min(self.response_times) if self.response_times else 0,
            "max_response_time": max(self.response_times) if self.response_times else 0
        }

class CRMTestSuite:
    """CRM系统性能测试套件"""
    
    def __init__(self, base_url: str = "http://localhost:5000"):
        self.base_url = base_url
        self.results: List[CRMTestResult] = []
        self.is_running = False
        
    def _generate_random_customer(self) -> Dict:
        """生成随机客户数据"""
        return {
            "name": f"Test_{''.join(random.choices(string.ascii_letters, k=10))}",
            "email": f"test_{random.randint(1000, 9999)}@example.com",
            "phone": f"138{random.randint(10000000, 99999999)}",
            "company": f"Company_{random.randint(100, 999)}"
        }
    
    def _test_single_request(self, method: str, endpoint: str, data: Dict = None) -> tuple[bool, float, str]:
        """执行单个HTTP请求测试"""
        try:
            url = f"{self.base_url}{endpoint}"
            start_time = time.time()
            
            if method == "GET":
                response = requests.get(url, params=data, timeout=5)
            elif method == "POST":
                response = requests.post(url, json=data, timeout=5)
            elif method == "PUT":
                response = requests.put(url, json=data, timeout=5)
            elif method == "DELETE":
                response = requests.delete(url, json=data, timeout=5)
            else:
                return False, 0, f"Unsupported method: {method}"
            
            response_time = time.time() - start_time
            
            if response.status_code in [200, 201]:
                return True, response_time, ""
            else:
                return False, response_time, f"HTTP Error {response.status_code}: {response.text}"
                
        except requests.exceptions.RequestException as e:
            return False, 0, f"Request failed: {str(e)}"
        except Exception as e:
            return False, 0, f"Unexpected error: {str(e)}"
    
    def _concurrent_test(self, test_func: Callable, num_users: int, iterations: int) -> CRMTestResult:
        """执行并发用户测试"""
        result = CRMTestResult(f"Concurrent {num_users} users")
        self.is_running = True
        
        completed = 0
        total = num_users * iterations
        
        def worker(user_id: int):
            """单个用户测试线程"""
            nonlocal completed
            try:
                for _ in range(iterations):
                    if not self.is_running:
                        break
                    success, response_time, error = test_func()
                    result.add_result(success, response_time, error)
                    completed += 1
                    if completed % 10 == 0:
                        print(f"进度: {completed}/{total} ({(completed/total)*100:.1f}%)", end="\r")
            except Exception as e:
                print(f"Worker {user_id} error: {str(e)}")
        
        threads = []
        try:
            for i in range(num_users):
                thread = threading.Thread(target=worker, args=(i,))
                threads.append(thread)
                thread.start()
            
            for thread in threads:
                thread.join()
                
        except KeyboardInterrupt:
            print("\n测试被用户中断...")
            self.is_running = False
            
        result.finalize()
        self.is_running = False
        print(f"\n测试完成: {completed}/{total} 请求")
        return result
    
    def test_concurrent_queries(self, num_users: int = 10, iterations: int = 10) -> CRMTestResult:
        """并发查询测试"""
        print(f"=== 开始并发查询测试 ({num_users}个用户，每个用户{iterations}次请求) ===")
        def query_test():
            return self._test_single_request("GET", "/api/customers", {"page": random.randint(1, 10)})
        
        result = self._concurrent_test(query_test, num_users, iterations)
        self.results.append(result)
        print(f"=== 并发查询测试完成 ===")
        return result
    
    def test_concurrent_updates(self, num_users: int = 50, iterations: int = 5) -> CRMTestResult:
        """并发更新测试"""
        print(f"=== 开始并发更新测试 ({num_users}个用户，每个用户{iterations}次请求) ===")
        def update_test():
            customer_id = random.randint(1, 1000)
            data = {"name": f"Updated_{random.randint(1000, 9999)}"}
            return self._test_single_request("PUT", f"/api/customers/{customer_id}", data)
        
        result = self._concurrent_test(update_test, num_users, iterations)
        self.results.append(result)
        print(f"=== 并发更新测试完成 ===")
        return result
    
    def test_data_volume(self, record_count: int = 10000) -> CRMTestResult:
        """数据量测试"""
        print(f"=== 开始数据量测试 ({record_count}条数据) ===")
        result = CRMTestResult(f"Data volume test with {record_count} records")
        
        # 测试查询性能
        for i in range(10):
            success, response_time, error = self._test_single_request(
                "GET", "/api/customers", {"page": random.randint(1, record_count//100)}
            )
            result.add_result(success, response_time, error)
            print(f"查询测试 {i+1}/10", end="\r")
        
        result.finalize()
        self.results.append(result)
        print(f"\n=== 数据量测试完成 ===")
        return result
    
    def test_api_performance(self, api_endpoint: str, method: str = "GET", iterations: int = 1000) -> CRMTestResult:
        """API性能测试"""
        print(f"=== 开始API性能测试 ({api_endpoint}, {method}, {iterations}次请求) ===")
        result = CRMTestResult(f"API performance test for {api_endpoint}")
        
        for i in range(iterations):
            data = self._generate_random_customer() if method in ["POST", "PUT"] else None
            success, response_time, error = self._test_single_request(method, api_endpoint, data)
            result.add_result(success, response_time, error)
            if i % 100 == 0:
                print(f"API测试 {i}/{iterations} ({(i/iterations)*100:.1f}%)", end="\r")
        
        result.finalize()
        self.results.append(result)
        print(f"\n=== API性能测试完成 ===")
        return result
    
    def test_system_resources(self, duration: int = 60) -> CRMTestResult:
        """系统资源监控测试"""
        print(f"=== 开始系统资源监控测试 ({duration}秒) ===")
        result = CRMTestResult(f"System resource monitoring for {duration}s")
        
        start_cpu = psutil.cpu_percent(interval=None)
        start_memory = psutil.virtual_memory().percent
        
        for i in range(duration):
            if i % 10 == 0:
                print(f"监控进度: {i}/{duration}秒", end="\r")
            time.sleep(1)
        
        end_cpu = psutil.cpu_percent(interval=None)
        end_memory = psutil.virtual_memory().percent
        
        result.add_result(True, 0, f"CPU: {start_cpu}% -> {end_cpu}%")
        result.add_result(True, 0, f"Memory: {start_memory}% -> {end_memory}%")
        
        result.finalize()
        self.results.append(result)
        print(f"\n=== 系统资源监控测试完成 ===")
        return result
    
    def test_edge_cases(self) -> CRMTestResult:
        """边缘场景测试"""
        print(f"=== 开始边缘场景测试 ===")
        result = CRMTestResult("Edge cases test")
        
        # 测试超大客户名称
        large_name = "A" * 1000
        data = {"name": large_name, "email": "test_large@example.com"}
        success, response_time, error = self._test_single_request("POST", "/api/customers", data)
        result.add_result(success, response_time, error)
        print(f"超大名称测试: {'成功' if success else '失败'}")
        
        # 测试特殊字符
        special_char_name = "Test😀"
        data = {"name": special_char_name, "email": "test_special@example.com"}
        success, response_time, error = self._test_single_request("POST", "/api/customers", data)
        result.add_result(success, response_time, error)
        print(f"特殊字符测试: {'成功' if success else '失败'}")
        
        result.finalize()
        self.results.append(result)
        print(f"=== 边缘场景测试完成 ===")
        return result
    
    def analyze_with_ai(self, test_results: List[CRMTestResult]) -> str:
        """使用AI分析测试结果"""
        if not AI_API_KEY:
            return "AI API key not configured"
        
        # 准备分析请求
        summaries = [result.get_summary() for result in test_results]
        
        prompt = f"""
        请分析以下CRM系统性能测试结果，提供专业的性能优化建议：
        {summaries}
        
        分析要点：
        1. 识别性能瓶颈
        2. 给出具体优化建议
        3. 评估系统整体稳定性
        4. 预测可能的故障点
        """
        
        try:
            headers = {
                "x-goog-api-key": AI_API_KEY,
                "Content-Type": "application/json"
            }
            
            data = {
                "contents": [
                    {
                        "role": "system",
                        "parts": [{"text": "你是一位资深的软件性能测试专家，擅长分析系统性能瓶颈并提供优化建议。请用中文回复。"}]
                    },
                    {
                        "role": "user",
                        "parts": [{"text": prompt}]
                    }
                ]
            }
            
            response = requests.post(AI_API_URL, headers=headers, json=data, timeout=30)
            response.raise_for_status()
            
            return response.json()
            
        except Exception as e:
            return f"AI analysis failed: {str(e)}"
    
    def run_full_test_suite(self) -> List[CRMTestResult]:
        """运行完整的测试套件"""
        print("=== 开始完整性能测试套件 ===")
        
        # 运行所有测试
        self.test_concurrent_queries(10, 10)
        self.test_concurrent_queries(50, 5)
        self.test_concurrent_queries(100, 3)
        
        self.test_concurrent_updates(20, 5)
        
        self.test_data_volume(10000)
        self.test_data_volume(100000)
        
        self.test_api_performance("/api/customers", "POST", 1000)
        self.test_api_performance("/api/customers/1", "DELETE", 1000)
        
        self.test_system_resources(60)
        
        self.test_edge_cases()
        
        print(f"=== 完成所有 {len(self.results)} 测试 ===")
        return self.results
    
    def generate_report(self) -> str:
        """生成测试报告"""
        report = "# CRM系统性能测试报告\n\n"
        report += f"测试时间: {datetime.now().isoformat()}\n\n"
        
        for result in self.results:
            summary = result.get_summary()
            report += f"## {summary['test_name']}\n"
            report += f"- 总请求数: {summary['total_requests']}\n"
            report += f"- 成功数: {summary['success_count']}\n"
            report += f"- 失败数: {summary['fail_count']}\n"
            report += f"- 成功率: {summary['success_rate']}%\n"
            report += f"- 平均响应时间: {summary['avg_response_time']:.3f}s\n"
            report += f"- 测试时长: {summary['duration']:.2f}s\n\n"
        
        return report

def main():
    """主函数，提供测试选项"""
    test_suite = CRMTestSuite()
    
    while True:
        print("\n=== CRM系统性能测试套件 ===")
        print("1. 完整测试套件")
        print("2. 并发查询测试")
        print("3. 并发更新测试")
        print("4. 数据量测试")
        print("5. API性能测试")
        print("6. 系统资源监控")
        print("7. 边缘场景测试")
        print("8. AI分析测试结果")
        print("9. 生成测试报告")
        print("0. 退出")
        
        choice = input("请选择测试类型: ")
        
        try:
            if choice == "1":
                test_suite.run_full_test_suite()
            elif choice == "2":
                num_users = int(input("请输入并发用户数 (默认10): ") or "10")
                iterations = int(input("请输入每个用户请求次数 (默认10): ") or "10")
                test_suite.test_concurrent_queries(num_users, iterations)
            elif choice == "3":
                num_users = int(input("请输入并发用户数 (默认50): ") or "50")
                iterations = int(input("请输入每个用户请求次数 (默认5): ") or "5")
                test_suite.test_concurrent_updates(num_users, iterations)
            elif choice == "4":
                record_count = int(input("请输入测试数据量 (默认10000): ") or "10000")
                test_suite.test_data_volume(record_count)
            elif choice == "5":
                api_endpoint = input("请输入API端点 (默认/api/customers): ") or "/api/customers"
                method = input("请输入HTTP方法 (默认GET): ") or "GET"
                iterations = int(input("请输入请求次数 (默认1000): ") or "1000")
                test_suite.test_api_performance(api_endpoint, method, iterations)
            elif choice == "6":
                duration = int(input("请输入监控时长(秒，默认60): ") or "60")
                test_suite.test_system_resources(duration)
            elif choice == "7":
                test_suite.test_edge_cases()
            elif choice == "8":
                if not test_suite.results:
                    print("请先运行测试")
                    continue
                ai_result = test_suite.analyze_with_ai(test_suite.results)
                print("\n--- AI分析结果 ---")
                print(ai_result)
            elif choice == "9":
                if not test_suite.results:
                    print("请先运行测试")
                    continue
                report = test_suite.generate_report()
                print(report)
                # 保存报告到文件
                report_file_name = f"crm_performance_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md"
                with open(report_file_name, "w") as f:
                    f.write(report)
                print(f"\n测试报告已保存到 {report_file_name}")
            elif choice == "0":
                print("退出测试套件")
                break
            else:
                print("无效选项，请重新选择")
        
        except KeyboardInterrupt:
            print("\n操作被用户中断")
            test_suite.is_running = False
        except Exception as e:
            print(f"发生错误: {str(e)}")

if __name__ == "__main__":
    main()